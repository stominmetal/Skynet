<?php

/* @var $this yii\web\View */

$this->title = 'Map';
?>
<div class="width-full">
    <div id="map"></div>
</div>

