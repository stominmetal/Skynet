<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=skynet',
    'username' => 'stomin',
    'password' => '1q2a3z4',
    'charset' => 'utf8',
];
